# Instructions


## Synopsis
The plan for the display id stored in the init.json file.  The server reads the instructions from the file and then provides the user with a console to get links for each screen of the display. Once all the screens are declared ready, the display will automatically start. The user will have buttons to pause and play the video.  

## Run on my cloud server (Recommended)
My app has been developed on a Linux machine, i have tested it to a limited extent on a Mac , but have not tested it on a windows machine. If you want to test it on your own device skip to Mac OS/Linux section, however i cannot guarantee their will be no problems with installation . My server has the installation already done for you. The files contain some configuration differences from the version on the github repo and submission but no work has been done post-deadline.


### 1. login to server via SSH
Mac OS and Linux will have a SSH client built in, to connect to the server. To login, simply put 
    `ssh root@project.andrewfriend.xyz`
into the console.
Otherwise if you have another system, you can use the browser based client [sshwifty](https://sshwifty.herokuapp.com/). Create an ssh session by pressing the red plus in the top left corner.



The password is: `Coursework2Prototype`, enter it when asked for password.

before being granted access, you might get a message like so:
   The authenticity of host 'project.andrewfriend.xyz (8.208.112.41)' can't be established.
    ED25519 key fingerprint is SHA256:Tb9NR2JUMHuafS/iR0RRjIn9L8Azhf7OqcHSWljpPX4.
    This key is not known by any other names
    Are you sure you want to continue connecting (yes/no/[fingerprint])? 
type `yes` and press enter.

once you gained access you will get a terminal like this: 
    Welcome to Ubuntu 20.04.3 LTS (GNU/Linux 5.4.0-90-generic x86_64)

        * Documentation:  https://help.ubuntu.com
        * Management:     https://landscape.canonical.com
        * Support:        https://ubuntu.com/advantage

        Welcome to Alibaba Cloud Elastic Compute Service !

    root@iZd7o2ma6kzlfwcwl0plinZ:~# 

First type `cd MediaSync/prototype` into the console and press enter to bring you into the prototype's directory.
Now follow the instructions under the "Run Application" heading.

## Mac OS/Linux 
To run on your own machine, follow these instructions.

### 1. unzip all files in to a folder

### 2. Install latest version of node.
Go to NodeJS [download page](https://nodejs.org/en/) and select "17.1.0 Current". Install via MacOS or Linux package manager.
### 3. Open terminal in directory
1. open terminal
2. type `cd PATH/TO/FOLDER` replacing `PATH/TO/FOLDER`/ with directory where you unzipped files.
### Install application 
1. Type `npm install` into console.


## Run application
1. Type `PORT=8000 node server.js` into terminal, this starts the server on port 8000.(on Linux you need admin privileges to run on port 80)
2. go into Chrome or Firefox (does not work on Safari, not sure about Edge) and type `project.andrewfriend.xyz:8000` (or local IP) into the address bar.
3. You will see the console.
4. The top dropdown box gives you options on what url to use. If on your own machine use localhost or local ip, otherwise use domain.
5. Open each link in new tab or window.
6. For each window, click "set screen to ready" button. The button will not appear until the videos load and this may take a minute or two depending on connection. During the wait it will show "Loading Video". 
7. When all are ready  the videos will start playing with their sequences in  sync. You can play or pause the display. Once the sequence has finished, too restart you need to close the node server (CTRL C in terminal) ,close all client pages, refresh console and start server again.
